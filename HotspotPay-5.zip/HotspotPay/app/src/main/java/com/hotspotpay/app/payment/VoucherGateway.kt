package com.hotspotpay.app.payment

import java.util.concurrent.ConcurrentHashMap

/**
 * Fully offline payment method: you (the hotspot owner) pre-generate voucher
 * codes — e.g. print them on slips of paper — and sell them for cash. This one
 * needs no backend or internet connection at all, unlike mobile money/card.
 */
class VoucherGateway {

    companion object {
        // code -> (minutes of access, already used)
        private val vouchers = ConcurrentHashMap<String, VoucherInfo>()

        data class VoucherInfo(
            val minutes: Int,
            val packageName: String = "",
            val price: Double = 0.0,
            var used: Boolean = false
        )

        /** Call this from your admin/owner screen to mint new codes to sell. */
        fun generate(minutes: Int = 60, packageName: String = "", price: Double = 0.0): String {
            val code = (100000..999999).random().toString()
            vouchers[code] = VoucherInfo(minutes, packageName, price)
            return code
        }

        fun allVouchers(): Map<String, VoucherInfo> = vouchers
    }

    fun redeem(code: String): PaymentResult {
        val voucher = vouchers[code]
        return when {
            voucher == null -> PaymentResult(success = false, message = "Invalid code")
            voucher.used -> PaymentResult(success = false, message = "Code already used")
            else -> {
                voucher.used = true
                PaymentResult(
                    success = true,
                    message = "Redeemed",
                    durationMillis = voucher.minutes * 60 * 1000L
                )
            }
        }
    }
}
