package com.hotspotpay.app

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log

/**
 * Wraps Android's LocalOnlyHotspot API.
 *
 * IMPORTANT LIMITATION (non-rooted device):
 * This is NOT the same as the regular "Portable Hotspot" toggle in system settings.
 * LocalOnlyHotspot is a separate, app-scoped hotspot that:
 *   - stops as soon as your app is killed/backgrounded too long without a foreground service
 *   - cannot reuse the phone's normal hotspot SSID/config
 *   - is the only hotspot mode a non-rooted app can actually gate traffic on, because
 *     Android does not expose the regular tethering data path to apps.
 *
 * If you need this to survive like a normal "always-on paid hotspot" business device,
 * you will eventually want a rooted device or a dedicated travel router (e.g. GL.iNet)
 * running proper captive-portal software (CoovaChilli / openNDS) instead of this app.
 */
class HotspotManager(private val context: Context) {

    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    interface Callback {
        fun onStarted(ssid: String, password: String)
        fun onFailed(reason: String)
        fun onStopped()
    }

    fun start(callback: Callback) {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager

        wifiManager.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
            override fun onStarted(res: WifiManager.LocalOnlyHotspotReservation) {
                reservation = res
                val config = res.wifiConfiguration
                val ssid = config?.SSID ?: res.softApConfiguration.ssid ?: "unknown"
                val password = config?.preSharedKey ?: res.softApConfiguration.passphrase ?: ""
                Log.i("HotspotManager", "Hotspot started: $ssid")
                callback.onStarted(ssid, password)
            }

            override fun onStopped() {
                Log.i("HotspotManager", "Hotspot stopped")
                callback.onStopped()
            }

            override fun onFailed(reason: Int) {
                Log.e("HotspotManager", "Hotspot failed to start: $reason")
                callback.onFailed("LocalOnlyHotspot failed, error code $reason")
            }
        }, null)
    }

    fun stop() {
        reservation?.close()
        reservation = null
    }
}
